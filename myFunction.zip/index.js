const { MongoClient, ObjectId } = require('mongodb');
const { SESClient, SendEmailCommand } = require("@aws-sdk/client-ses");

const REGION = process.env.REGION;
const MONGODB_URI = process.env.MONGODB_URI;
const DATABASE_NAME = process.env.DATABASE_NAME;
const COLLECTION_NAME = process.env.COLLECTION_NAME;
const EMAIL = process.env.EMAIL;

const sesClient = new SESClient({
  region: REGION,
  credentials: {
    accessKeyId: "AKIA554T34LZH45GBH4D",
    secretAccessKey: "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",
  },
});

const client = new MongoClient(MONGODB_URI, { maxPoolSize: 2, useNewUrlParser: true, useUnifiedTopology: true });

async function getJobStatus(event) {
  const jobStatusMap = {
    'RUNNING': 0,
    'SUCCEEDED': 1,
    'FAILED': -1,
  };
  return jobStatusMap[event.detail.status];
}

async function updateJobStatus(detail, status, client) {
  const db = client.db(DATABASE_NAME);
  const applyInfoCollection = db.collection(COLLECTION_NAME)


  const jobDoc = await applyInfoCollection.findOne({ jobId: detail.jobId });
  if (status == 1 || status == -1) {
    const taskDetailCollection = db.collection("taskDetail")
    const logDb = client.db('cb_logs')
    
    await taskDetailCollection.insertOne(detail)
    if (jobDoc) {
      await logDb.collection(jobDoc.result).insertOne({
        "content": null,
        "index": -1,
        "programStage": "CONTAINER_EXIT",
        "time": 0
      })
    }
  }
  if (jobDoc) {
    await applyInfoCollection.updateOne(
      { _id: jobDoc._id },
      {
        $set: { status, message: detail.container.reason},
        $currentDate: { lastModifiedDate: true }
      }
    );
    jobDoc.message = detail.container.reason || detail.statusReason
    return jobDoc;
  }
  return null;
}

async function sendStatusEmail(jobDoc, status, users) {
  if (status == 'SUCCEEDED' || status == 'FAILED') {
    const doc = await users.findOne({ _id: new ObjectId(jobDoc.userId) });
    if (doc) {
      const emailParams = {
        Source: `Job status update <no-reply@ai.trusetics.com>`,
        Destination: { ToAddresses: [doc.email] },
        Message: {
          Subject: {
            Data: `Job Status: ${status}`,
            Charset: 'UTF-8'
          },
          Body: {
            Html: {
              Data: `
<html>
<body>
<p>Dear User,</p>
<p>This email is to notify you about the status of your data job.</p>
<p><b>Job ID:</b> ${jobDoc.result}<br>
<b>Dataset:</b> ${jobDoc.name}<br>
<b>Datatype:</b> ${jobDoc.datatype}<br>
<b>Number of Epochs:</b> ${jobDoc.epochs}<br>
<b>Number of Rows:</b> ${jobDoc.rows}<br>
<b>Model Name:</b> Trusetics Synthesizer<br>
<b>Creation Date:</b> ${jobDoc.createdDate}<br>
<b>Last Modified Date:</b> ${jobDoc.lastModifiedDate}<br>
<p>The current status of your job is: ${status}</p>
<p><b>Message:</b> ${jobDoc.message ? jobDoc.message : 'No additional information'}</p>
<p>If you have any issues or questions, feel free to reach out to our support team at <a href="mailto:${EMAIL}">${EMAIL}</a>.</p>
<p>Best,<br>Trusetics Team</p>
</body>
</html>`,
              Charset: 'UTF-8'
            }
          }
        }
      };
      await sesClient.send(new SendEmailCommand(emailParams));
    }
  }
}

async function updateJobLogStream(detail, db) {
  const applyInfoCollection = db.collection(COLLECTION_NAME)


  const jobDoc = await applyInfoCollection.findOne({ jobId: detail.jobId });
  if (jobDoc) {
    await applyInfoCollection.updateOne(
      { _id: jobDoc._id },
      {
        $set: { logStreamName: detail.container.logStreamName },
        $currentDate: { lastModifiedDate: true }
      }
    );
    return jobDoc;
  }
  return null;
}

exports.handler = async (event, context) => {
  console.log(MONGODB_URI)
  console.log(DATABASE_NAME)
  console.log(COLLECTION_NAME)


  const status = await getJobStatus(event);

  if (event.detail.status == 'STARTING') {
    await client.connect();
    const db = client.db(DATABASE_NAME);
    await updateJobLogStream(event.detail,db)
    return
  }

  if (status != null) {
    await client.connect();
    const db = client.db(DATABASE_NAME);
    const users = db.collection("users");
    try {
      const jobDoc = await updateJobStatus(event.detail, status, client);
      if (jobDoc && EMAIL) {
        await sendStatusEmail(jobDoc, event.detail.status, users);
      }
    } catch (error) {
      console.error(error);
    } finally {
      await client.close();
    }
  }
};
