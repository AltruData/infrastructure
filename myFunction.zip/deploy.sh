#!/bin/bash
rm myFunction.zip
zip -r myFunction.zip .
aws lambda update-function-code --function-name my-function \
--zip-file fileb://myFunction.zip